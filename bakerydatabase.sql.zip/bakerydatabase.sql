-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 18, 2020 at 03:42 PM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bakerydatabase`
--

-- --------------------------------------------------------

--
-- Table structure for table `item1`
--

CREATE TABLE IF NOT EXISTS `item1` (
  `item_code` varchar(5) NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `rate` varchar(10) NOT NULL,
  `stock_in_hand` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item1`
--

INSERT INTO `item1` (`item_code`, `item_name`, `rate`, `stock_in_hand`) VALUES
('001', 'Butter Bread (L)', '300', ''),
('002', 'Butter Bread (M)', '150', '250'),
('003', 'Butter Bread (S)', '300', '105'),
('004', 'Sliced Butter Bread (L)', '300', '95'),
('005', 'Chocolate Bread', '350', '50'),
('006', 'Fruitie 800g', '400', '115'),
('007', 'Fruitie 400g', '200', '162'),
('008', 'Whole Wheat', '450', '60'),
('009', 'Suasage Bread', '100', '90');

-- --------------------------------------------------------

--
-- Table structure for table `item2`
--

CREATE TABLE IF NOT EXISTS `item2` (
  `customer_code` varchar(10) NOT NULL,
  `customer_name` varchar(40) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `phone_no` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `item3`
--

CREATE TABLE IF NOT EXISTS `item3` (
  `BillNo` varchar(15) NOT NULL,
  `customer_type` varchar(20) NOT NULL,
  `Buyers_Name` varchar(40) NOT NULL,
  `Date` varchar(10) NOT NULL,
  `item_code` varchar(10) NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `Quantity` varchar(10) NOT NULL,
  `Amount` varchar(10) NOT NULL,
  `Discount` varchar(10) NOT NULL,
  `Net_Amount` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item3`
--

INSERT INTO `item3` (`BillNo`, `customer_type`, `Buyers_Name`, `Date`, `item_code`, `item_name`, `Quantity`, `Amount`, `Discount`, `Net_Amount`) VALUES
('BUBAKERY/', 'End-User', '', '31/3/2019', '004', 'Sliced Butter Bread (L)', '10', '3000', '0.0', '3000.0'),
('BUBAKERY/001', 'Distributor', 'Olaniyi Opeyemi', '08/06/2017', '001', 'Normal Bread', '100', '17000', '4000.0', '13000.0'),
('BUBAKERY/002', 'End-User', 'Apejoye Oladipo', '08/06/2017', '002', 'Butter Bread', '50', '17500', '0.0', '17500.0'),
('BUBAKERY/003', 'End-User', 'Oyeleye Emmanuel', '08/06/2017', '001', 'Normal Bread', '50', '8500', '0.0', '8500.0'),
('BUBAKERY/004', 'Distributor', 'Odeyemi Daniel', '08/06/2017', '004', 'Chocolate Bread', '100', '40000', '4000.0', '36000.0'),
('BUBAKERY/005', 'End-User', 'Kehinde Kayode', '08/06/2017', '003', 'Wheat Bread', '10', '4000', '0.0', '4000.0'),
('BUBAKERY/006', 'Distributor', 'Olawuyi Bisi', '08/06/2017', '002', 'Butter Bread', '50', '17500', '2000.0', '15500.0'),
('BUBAKERY/007', 'Distributor', 'Oladipo Oluwaseun', '08/06/2017', '002', 'Butter Bread', '100', '35000', '4000.0', '31000.0'),
('BUBAKERY/008', 'End-User', 'Omoniyi Jumoke', '08/06/2017', '001', 'Normal Bread', '10', '1700', '0.0', '1700.0'),
('BUBAKERY/009', 'End-User', 'Olaleye Isaac', '11/6/2017', '001', 'Butter Bread (L)', '10', '3000', '0.0', '3000.0'),
('BUBAKERY/010', 'End-User', 'Akin Sola', '11/6/2017', '002', 'Butter Bread (M)', '20', '3000', '0.0', '3000.0');

-- --------------------------------------------------------

--
-- Table structure for table `item4`
--

CREATE TABLE IF NOT EXISTS `item4` (
  `Supplier_code` varchar(10) NOT NULL,
  `Supplier_name` varchar(40) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `phone_no` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item4`
--

INSERT INTO `item4` (`Supplier_code`, `Supplier_name`, `address`, `city`, `state`, `phone_no`) VALUES
('001', 'Olaniyi Opeyemi', 'Bowen University', 'Iwo', 'Osun State', '08167084120');

-- --------------------------------------------------------

--
-- Table structure for table `item5`
--

CREATE TABLE IF NOT EXISTS `item5` (
  `item_code` varchar(10) NOT NULL,
  `item_name` varchar(30) NOT NULL,
  `Stock_in_hand` varchar(10) NOT NULL,
  `New_stock` varchar(10) NOT NULL,
  `Date_added` varchar(20) NOT NULL,
  `Total_Stock` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item5`
--

INSERT INTO `item5` (`item_code`, `item_name`, `Stock_in_hand`, `New_stock`, `Date_added`, `Total_Stock`) VALUES
('001', 'Butter Bread (L)', '200', '20', '09/06/2017', '220'),
('002', 'Butter Bread (M)', '250', '20', '09/06/2017', '270'),
('003', 'Butter Bread (S)', '90', '15', '09/06/2017', '105'),
('004', 'Sliced Butter Bread (L)', '110', '5', '09/06/2017', '115'),
('005', 'Chocolate Bread', '40', '10', '09/06/2017', '50'),
('006', 'Fruitie 800g', '100', '15', '09/06/2017', '115'),
('007', 'Fruitie 400g', '160', '2', '09/06/2017', '162'),
('008', 'Whole Wheat', '50', '10', '09/06/2017', '60'),
('009', 'Suasage Bread', '60', '30', '09/06/2017', '90'),
('001', '', '', '', '20/1/2019', '');

-- --------------------------------------------------------

--
-- Table structure for table `item6`
--

CREATE TABLE IF NOT EXISTS `item6` (
  `code` varchar(5) NOT NULL,
  `name` varchar(20) NOT NULL,
  `rate` varchar(10) NOT NULL,
  `stock_in_hand` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item6`
--

INSERT INTO `item6` (`code`, `name`, `rate`, `stock_in_hand`) VALUES
('001', 'Flour', '3000', '110'),
('002', 'Sugar', '2000', '102'),
('003', 'Butter', '1000', '290'),
('004', 'Magrine', '700', '123'),
('005', 'Vegetable Oil', '4000', '290'),
('006', 'Improver', '300', '529'),
('007', 'Salt', '5000', '180'),
('008', 'Flavour', '70', '269'),
('009', 'Nutmeg', '50', '570'),
('010', 'Milk', '6000', '160'),
('011', 'Yeast', '750', '600');

-- --------------------------------------------------------

--
-- Table structure for table `item7`
--

CREATE TABLE IF NOT EXISTS `item7` (
  `code` varchar(10) NOT NULL,
  `name` varchar(30) NOT NULL,
  `stock_in_hand` varchar(10) NOT NULL,
  `new_stock` varchar(10) NOT NULL,
  `date_added` varchar(20) NOT NULL,
  `total` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item7`
--

INSERT INTO `item7` (`code`, `name`, `stock_in_hand`, `new_stock`, `date_added`, `total`) VALUES
('001', 'Flour', '100', '10', '09/06/2017', '110'),
('002', 'Sugar', '100', '12', 'null', '112'),
('003', 'Butter', '300', '10', 'null', '310'),
('004', 'Magrine', '100', '23', 'null', '123'),
('005', 'Vegetable Oil', '200', '120', 'null', '320'),
('006', 'Improver', '500', '29', 'null', '529'),
('007', 'Salt', '150', '50', 'null', '200'),
('008', 'Flavour', '250', '19', 'null', '269'),
('009', 'Nutmeg', '500', '100', 'null', '600'),
('010', 'Milk', '150', '10', 'null', '160'),
('011', 'Yeast', '500', '120', 'null', '620');

-- --------------------------------------------------------

--
-- Table structure for table `item8`
--

CREATE TABLE IF NOT EXISTS `item8` (
  `code` varchar(5) NOT NULL,
  `name` varchar(30) NOT NULL,
  `stock_in_hand` varchar(10) NOT NULL,
  `new_stock` varchar(10) NOT NULL,
  `date_out` varchar(20) NOT NULL,
  `total` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item8`
--

INSERT INTO `item8` (`code`, `name`, `stock_in_hand`, `new_stock`, `date_out`, `total`) VALUES
('002', 'Sugar', '112', '10', '09/06/2017', '102'),
('003', 'Butter', '310', '20', 'null', '290'),
('005', 'Vegetable Oil', '320', '30', 'null', '290'),
('007', 'Salt', '200', '20', 'null', '180'),
('009', 'Nutmeg', '600', '30', 'null', '570'),
('011', 'Yeast', '620', '20', 'null', '600');

-- --------------------------------------------------------

--
-- Table structure for table `userinput`
--

CREATE TABLE IF NOT EXISTS `userinput` (
  `User_Id` varchar(10) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `Access_Level` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userinput`
--

INSERT INTO `userinput` (`User_Id`, `Password`, `Access_Level`) VALUES
('admin', 'admin', '5'),
('oladipo', 'oladipo', '1'),
('emmanuel', 'emmanuel', '2'),
('smiles', 'smiles', '3'),
('ife', 'ife', '5');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `item1`
--
ALTER TABLE `item1`
 ADD UNIQUE KEY `item_code` (`item_code`);

--
-- Indexes for table `item2`
--
ALTER TABLE `item2`
 ADD UNIQUE KEY `customer_code` (`customer_code`);

--
-- Indexes for table `item3`
--
ALTER TABLE `item3`
 ADD UNIQUE KEY `BillNo` (`BillNo`);

--
-- Indexes for table `item4`
--
ALTER TABLE `item4`
 ADD UNIQUE KEY `Supplier_code` (`Supplier_code`);

--
-- Indexes for table `item6`
--
ALTER TABLE `item6`
 ADD UNIQUE KEY `code` (`code`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
